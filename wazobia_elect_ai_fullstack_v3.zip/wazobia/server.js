// ================================================================
// WAZOBIA ELECT AI — FULL STACK BACKEND v3.0
// Production-grade Nigerian Electoral Platform
// Stack: Express · MongoDB · Socket.io · JWT · Web3 · Rate Limiting
// ================================================================

const express    = require('express');
const mongoose   = require('mongoose');
const cors       = require('cors');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const http       = require('http');
const { Server } = require('socket.io');
const crypto     = require('crypto');
const path       = require('path');

// ── Optional deps (gracefully degrade if not installed) ──────────
let rateLimit, helmet, mongoSanitize;
try { rateLimit      = require('express-rate-limit'); }    catch {}
try { helmet         = require('helmet'); }                catch {}
try { mongoSanitize  = require('express-mongo-sanitize'); } catch {}

// ================================================================
// SETUP
// ================================================================
const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*', methods: ['GET','POST'] }
});

const PORT       = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'wazobia_elect_ai_super_secret_2027_nigeria';
const MONGO_URI  = process.env.MONGO_URI  || 'mongodb://127.0.0.1:27017/wazobia_elect_ai';
const ADMIN_KEY  = process.env.ADMIN_KEY  || 'INEC_ADMIN_2027';

// ── Middleware ────────────────────────────────────────────────────
if (helmet)        app.use(helmet({ contentSecurityPolicy: false }));
if (mongoSanitize) app.use(mongoSanitize());

app.use(cors());
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Rate limiting — prevent brute force
if (rateLimit) {
  app.use('/login',    rateLimit({ windowMs: 15*60*1000, max: 10,  message: { message: 'Too many login attempts. Try again in 15 minutes.' } }));
  app.use('/register', rateLimit({ windowMs: 60*60*1000, max: 5,   message: { message: 'Registration limit reached. Contact INEC.' } }));
  app.use('/vote',     rateLimit({ windowMs: 60*60*1000, max: 6,   message: { message: 'Voting rate limit reached.' } }));
}

// ================================================================
// DATABASE
// ================================================================
mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(() => {
    console.log('✅ MongoDB Connected:', MONGO_URI);
    seedDemoData();
  })
  .catch(err => {
    console.warn('⚠️  MongoDB not available — running in DEMO mode');
    console.warn('   Start MongoDB or set MONGO_URI env variable');
  });

// ================================================================
// BLOCKCHAIN SIMULATION
// (Real Web3 anchoring requires funded wallet + deployed contract)
// ================================================================
const blockchainLedger = [];
let blockCount = 14823;

function hashVote(payload) {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify(payload) + Date.now())
    .digest('hex');
}

function mineBlock(type, data, hash) {
  const prevHash = blockchainLedger.length
    ? blockchainLedger[blockchainLedger.length - 1].hash
    : '0000000000000000000000000000000000000000000000000000000000000000';

  const block = {
    index:     ++blockCount,
    type,
    data,
    hash,
    prevHash,
    timestamp: new Date().toISOString(),
    nonce:     Math.floor(Math.random() * 999999),
  };

  blockchainLedger.push(block);
  io.emit('newBlock', block);
  return block;
}

// ================================================================
// MONGOOSE MODELS
// ================================================================

// ── User ─────────────────────────────────────────────────────────
const UserSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true, maxlength: 100 },
  email:     { type: String, required: true, unique: true, lowercase: true, trim: true },
  password:  { type: String, required: true },
  nin:       { type: String, required: true, unique: true, length: 11 },
  phone:     { type: String, trim: true },
  state:     { type: String, trim: true },
  lga:       { type: String, trim: true },
  ward:      { type: String, trim: true },
  pollingUnit: { type: String, trim: true },
  hasVoted:  { type: Boolean, default: false },
  votedAt:   { type: Date },
  isVerified:{ type: Boolean, default: false },
  role:      { type: String, enum: ['voter','admin','observer'], default: 'voter' },
  loginAttempts: { type: Number, default: 0 },
  lockedUntil:   { type: Date },
  createdAt: { type: Date, default: Date.now },
});

// ── Vote ──────────────────────────────────────────────────────────
const VoteSchema = new mongoose.Schema({
  userId:        { type: String, required: true, index: true },
  nin:           { type: String, required: true },
  candidate:     { type: String, required: true },
  party:         { type: String, required: true },
  level:         { type: String, required: true },   // Presidential, Senate, etc.
  state:         { type: String },
  lga:           { type: String },
  ward:          { type: String },
  pollingUnit:   { type: String },
  hash:          { type: String, required: true, unique: true, index: true },
  blockIndex:    { type: Number },
  zkProof:       { type: String },   // simulated zero-knowledge proof
  encryptedData: { type: String },   // AES-256-GCM encrypted payload
  ipHash:        { type: String },   // hashed IP (privacy)
  verified:      { type: Boolean, default: true },
  createdAt:     { type: Date, default: Date.now },
});

// ── Audit Log ─────────────────────────────────────────────────────
const AuditSchema = new mongoose.Schema({
  event:     { type: String, required: true },
  userId:    { type: String },
  nin:       { type: String },
  ipHash:    { type: String },
  details:   { type: Object },
  severity:  { type: String, enum: ['info','warn','error','critical'], default: 'info' },
  timestamp: { type: Date, default: Date.now },
});

// ── FraudFlag ────────────────────────────────────────────────────
const FraudSchema = new mongoose.Schema({
  type:      { type: String, required: true },
  details:   { type: Object },
  resolved:  { type: Boolean, default: false },
  severity:  { type: String, enum: ['low','medium','high','critical'] },
  timestamp: { type: Date, default: Date.now },
});

const User      = mongoose.model('User',     UserSchema);
const Vote      = mongoose.model('Vote',     VoteSchema);
const AuditLog  = mongoose.model('AuditLog', AuditSchema);
const FraudFlag = mongoose.model('FraudFlag',FraudSchema);

// ================================================================
// HELPERS
// ================================================================
function hashIP(ip) {
  return crypto.createHash('sha256').update(ip + 'wazobia_salt').digest('hex').slice(0,16);
}

function generateZKProof(userId, candidate) {
  // Simulated zero-knowledge proof (real implementation uses zk-SNARKs library)
  const commitment = crypto.createHash('sha256').update(userId + candidate + 'zk_secret').digest('hex');
  return `zk_${commitment.slice(0,32)}`;
}

function encryptPayload(data) {
  // AES-256-GCM encryption simulation
  const key   = crypto.scryptSync('wazobia_key', 'salt', 32);
  const iv    = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(data)), cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

async function auditLog(event, userId, nin, ip, details, severity = 'info') {
  try {
    await new AuditLog({
      event, userId, nin,
      ipHash: ip ? hashIP(ip) : null,
      details, severity
    }).save();
  } catch { /* non-blocking */ }
}

// ================================================================
// MIDDLEWARE
// ================================================================
function auth(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ success: false, message: 'Authentication required' });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

function adminAuth(req, res, next) {
  const key = req.headers['x-admin-key'];
  if (key !== ADMIN_KEY) return res.status(403).json({ success: false, message: 'Admin access denied' });
  next();
}

// ================================================================
// ROUTES — AUTH
// ================================================================

// ── POST /register ────────────────────────────────────────────────
app.post('/register', async (req, res) => {
  try {
    const { name, email, password, nin, phone, state, lga, ward, pollingUnit } = req.body;

    // Validation
    if (!name || !email || !password || !nin)
      return res.status(400).json({ success: false, message: 'Name, email, password, and NIN are required' });

    if (nin.length !== 11 || !/^\d+$/.test(nin))
      return res.status(400).json({ success: false, message: 'NIN must be exactly 11 digits' });

    if (password.length < 8)
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters' });

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return res.status(400).json({ success: false, message: 'Invalid email address' });

    // Uniqueness checks
    if (await User.findOne({ email }))
      return res.status(409).json({ success: false, message: 'Email already registered' });

    if (await User.findOne({ nin }))
      return res.status(409).json({ success: false, message: 'NIN already registered in the voters register' });

    const hashed = await bcrypt.hash(password, 12);

    const user = await new User({
      name, email,
      password: hashed,
      nin, phone, state, lga, ward, pollingUnit,
      isVerified: false,
    }).save();

    // Mine registration block
    mineBlock('VOTER_REGISTERED', { userId: user._id, state }, hashVote({ nin, email }));

    await auditLog('REGISTRATION', user._id, nin, req.ip, { state, lga });

    io.emit('voterRegistered', { state, total: await User.countDocuments() });

    res.status(201).json({
      success: true,
      message: 'Registration successful. Proceed to biometric verification.',
      userId: user._id,
    });

  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error during registration' });
  }
});

// ── POST /login ───────────────────────────────────────────────────
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ success: false, message: 'Email and password required' });

    const user = await User.findOne({ email });
    if (!user) {
      await auditLog('LOGIN_FAILED', null, null, req.ip, { email, reason: 'user_not_found' }, 'warn');
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    // Account lockout (5 failed attempts)
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const mins = Math.ceil((user.lockedUntil - new Date()) / 60000);
      return res.status(423).json({ success: false, message: `Account locked. Try again in ${mins} minute(s).` });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      user.loginAttempts = (user.loginAttempts || 0) + 1;
      if (user.loginAttempts >= 5) {
        user.lockedUntil = new Date(Date.now() + 30 * 60 * 1000); // 30 min lockout
        await auditLog('ACCOUNT_LOCKED', user._id, user.nin, req.ip, {}, 'critical');
      }
      await user.save();
      await auditLog('LOGIN_FAILED', user._id, user.nin, req.ip, { attempts: user.loginAttempts }, 'warn');
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    // Reset lockout on success
    user.loginAttempts = 0;
    user.lockedUntil   = null;
    await user.save();

    const token = jwt.sign(
      { id: user._id, nin: user.nin, role: user.role },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    await auditLog('LOGIN_SUCCESS', user._id, user.nin, req.ip, {});

    res.json({
      success: true,
      token,
      voter: {
        name: user.name,
        nin:  user.nin,
        state: user.state,
        lga:   user.lga,
        ward:  user.ward,
        pollingUnit: user.pollingUnit,
        hasVoted: user.hasVoted,
        role: user.role,
      }
    });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
});

// ── POST /verify-nin ──────────────────────────────────────────────
app.post('/verify-nin', async (req, res) => {
  try {
    const { nin } = req.body;
    if (!nin || nin.length !== 11)
      return res.status(400).json({ success: false, message: 'Invalid NIN format' });

    const user = await User.findOne({ nin });
    if (!user)
      return res.status(404).json({ success: false, message: 'NIN not found in voters register' });

    // Simulate BVAS/biometric verification
    res.json({
      success: true,
      voter: {
        name:        user.name,
        nin:         user.nin,
        state:       user.state,
        lga:         user.lga,
        ward:        user.ward,
        pollingUnit: user.pollingUnit,
        hasVoted:    user.hasVoted,
        status:      'Accredited',
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: 'NIN verification error' });
  }
});

// ================================================================
// ROUTES — VOTING
// ================================================================

// ── POST /vote ────────────────────────────────────────────────────
app.post('/vote', auth, async (req, res) => {
  try {
    const { candidate, party, level, state, lga, ward, pollingUnit } = req.body;

    if (!candidate || !party || !level)
      return res.status(400).json({ success: false, message: 'Candidate, party, and election level are required' });

    const user = await User.findById(req.user.id);
    if (!user)
      return res.status(404).json({ success: false, message: 'Voter not found' });

    if (user.hasVoted)
      return res.status(409).json({ success: false, message: 'You have already cast your vote. Each voter may only vote once.' });

    // ── Fraud detection checks ────────────────────────────────────
    const ipHash = hashIP(req.ip);

    // Check for IP-based anomaly (multiple votes from same IP)
    const ipVotes = await Vote.countDocuments({ ipHash, createdAt: { $gte: new Date(Date.now() - 60*60*1000) } });
    if (ipVotes > 50) {
      await new FraudFlag({ type: 'IP_FLOOD', details: { ipHash, count: ipVotes }, severity: 'high' }).save();
      await auditLog('FRAUD_ATTEMPT', user._id, user.nin, req.ip, { type: 'ip_flood' }, 'critical');
      return res.status(429).json({ success: false, message: 'Voting anomaly detected. Security flag raised.' });
    }

    // ── Build encrypted vote payload ──────────────────────────────
    const votePayload = {
      userId:    user._id.toString(),
      nin:       user.nin,
      candidate,
      party,
      level,
      timestamp: Date.now(),
    };

    const voteHash      = hashVote(votePayload);
    const zkProof       = generateZKProof(user._id.toString(), candidate);
    const encryptedData = encryptPayload(votePayload);

    // ── Save vote ─────────────────────────────────────────────────
    const vote = await new Vote({
      userId:      user._id,
      nin:         user.nin,
      candidate,
      party,
      level,
      state:       state  || user.state,
      lga:         lga    || user.lga,
      ward:        ward   || user.ward,
      pollingUnit: pollingUnit || user.pollingUnit,
      hash:        voteHash,
      zkProof,
      encryptedData,
      ipHash,
    }).save();

    // Mark voter
    user.hasVoted = true;
    user.votedAt  = new Date();
    await user.save();

    // Mine block
    const block = mineBlock('VOTE_CAST', {
      level, party, state: state || user.state,
    }, voteHash);
    await Vote.findByIdAndUpdate(vote._id, { blockIndex: block.index });

    // Broadcast live results
    const results = await getLiveResults();
    io.emit('liveResults', results);
    io.emit('voteCast', {
      level, state: state || user.state,
      totalVotes: results.totalVotes,
    });

    await auditLog('VOTE_CAST', user._id, user.nin, req.ip, { level, party, state });

    res.json({
      success:    true,
      message:    'Your vote has been cast, encrypted, and anchored to the blockchain.',
      receipt: {
        code:       `WZB-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substr(2,6).toUpperCase()}`,
        hash:       voteHash,
        zkProof,
        blockIndex: block.index,
        timestamp:  new Date().toISOString(),
        verification: `https://wazobiaelect.ai/verify/${voteHash}`,
      }
    });

  } catch (err) {
    console.error('Vote error:', err);
    if (err.code === 11000)
      return res.status(409).json({ success: false, message: 'Duplicate vote detected and blocked.' });
    res.status(500).json({ success: false, message: 'Voting system error. Please try again.' });
  }
});

// ── POST /vote/batch ──────────────────────────────────────────────
// Submit votes for multiple election levels simultaneously
app.post('/vote/batch', auth, async (req, res) => {
  try {
    const { votes } = req.body; // Array of { candidate, party, level }
    if (!Array.isArray(votes) || votes.length === 0)
      return res.status(400).json({ success: false, message: 'Votes array required' });
    if (votes.length > 6)
      return res.status(400).json({ success: false, message: 'Maximum 6 election levels per ballot' });

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'Voter not found' });
    if (user.hasVoted) return res.status(409).json({ success: false, message: 'Already voted' });

    const receipts = [];
    const ipHash = hashIP(req.ip);

    for (const v of votes) {
      if (!v.candidate || !v.party || !v.level) continue;

      const payload  = { userId: user._id.toString(), nin: user.nin, ...v, timestamp: Date.now() };
      const hash     = hashVote(payload);
      const zkProof  = generateZKProof(user._id.toString(), v.candidate);
      const encData  = encryptPayload(payload);

      const vote = await new Vote({
        userId: user._id, nin: user.nin,
        ...v,
        state: user.state, lga: user.lga, ward: user.ward, pollingUnit: user.pollingUnit,
        hash, zkProof, encryptedData: encData, ipHash,
      }).save();

      const block = mineBlock('VOTE_CAST_BATCH', { level: v.level, party: v.party }, hash);
      await Vote.findByIdAndUpdate(vote._id, { blockIndex: block.index });

      receipts.push({
        level:      v.level,
        candidate:  v.candidate,
        party:      v.party,
        hash,
        zkProof,
        blockIndex: block.index,
      });
    }

    user.hasVoted = true;
    user.votedAt  = new Date();
    await user.save();

    const results = await getLiveResults();
    io.emit('liveResults', results);

    res.json({
      success: true,
      message: `${receipts.length} vote(s) cast, encrypted, and anchored to the blockchain.`,
      receipts,
      masterCode: `WZB-BATCH-${Date.now().toString(36).toUpperCase()}`,
    });

  } catch (err) {
    console.error('Batch vote error:', err);
    res.status(500).json({ success: false, message: 'Batch voting error' });
  }
});

// ================================================================
// ROUTES — RESULTS
// ================================================================
async function getLiveResults() {
  const [presidential, senate, house, totalVotes, totalVoters, states] = await Promise.all([
    Vote.aggregate([
      { $match: { level: 'Presidential' } },
      { $group: { _id: { candidate: '$candidate', party: '$party' }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]),
    Vote.aggregate([
      { $match: { level: 'Senate' } },
      { $group: { _id: { candidate: '$candidate', party: '$party' }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]),
    Vote.aggregate([
      { $match: { level: 'House' } },
      { $group: { _id: { candidate: '$candidate', party: '$party' }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]),
    Vote.countDocuments(),
    User.countDocuments(),
    Vote.aggregate([
      { $match: { level: 'Presidential' } },
      { $group: { _id: { state: '$state', party: '$party' }, count: { $sum: 1 } } },
      { $sort: { '_id.state': 1, count: -1 } }
    ]),
  ]);

  return { presidential, senate, house, totalVotes, totalVoters, states, blockchain: { blocks: blockCount, synced: true } };
}

app.get('/results', async (req, res) => {
  try {
    res.json({ success: true, data: await getLiveResults() });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Results error' });
  }
});

app.get('/results/:level', async (req, res) => {
  try {
    const results = await Vote.aggregate([
      { $match: { level: req.params.level } },
      { $group: { _id: { candidate: '$candidate', party: '$party', state: '$state' }, count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);
    res.json({ success: true, level: req.params.level, results });
  } catch {
    res.status(500).json({ success: false, message: 'Results error' });
  }
});

// ── GET /verify/:hash ─────────────────────────────────────────────
app.get('/verify/:hash', async (req, res) => {
  try {
    const vote = await Vote.findOne({ hash: req.params.hash });
    if (!vote)
      return res.json({ success: false, valid: false, message: 'Receipt not found on the ledger' });

    res.json({
      success: true,
      valid:   true,
      message: 'Vote verified on the blockchain',
      data: {
        level:      vote.level,
        blockIndex: vote.blockIndex,
        zkProof:    vote.zkProof,
        timestamp:  vote.createdAt,
        verified:   vote.verified,
      }
    });
  } catch {
    res.status(500).json({ success: false, message: 'Verification error' });
  }
});

// ── GET /blockchain ────────────────────────────────────────────────
app.get('/blockchain', async (req, res) => {
  res.json({
    success: true,
    blocks:  blockCount,
    ledger:  blockchainLedger.slice(-20).reverse(),
    synced:  true,
    nodes:   12,
  });
});

// ================================================================
// ROUTES — ADMIN (protected by admin key)
// ================================================================
app.get('/admin/dashboard', adminAuth, async (req, res) => {
  try {
    const [
      totalVotes, totalUsers, fraudFlags,
      results, byState, byLevel, recentVotes, recentUsers
    ] = await Promise.all([
      Vote.countDocuments(),
      User.countDocuments(),
      FraudFlag.countDocuments(),
      Vote.aggregate([
        { $match: { level: 'Presidential' } },
        { $group: { _id: { candidate: '$candidate', party: '$party' }, count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      Vote.aggregate([
        { $group: { _id: '$state', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]),
      Vote.aggregate([
        { $group: { _id: '$level', count: { $sum: 1 } } }
      ]),
      Vote.find().sort({ createdAt: -1 }).limit(10).lean(),
      User.find().sort({ createdAt: -1 }).limit(10).select('-password').lean(),
    ]);

    const turnout = totalUsers > 0 ? ((totalVotes / totalUsers) * 100).toFixed(1) : 0;

    res.json({
      success: true,
      stats: { totalVotes, totalUsers, fraudFlags, turnout, blockchainBlocks: blockCount },
      results,
      byState,
      byLevel,
      recentVotes: recentVotes.map(v => ({
        level: v.level, party: v.party, state: v.state,
        hash: v.hash.slice(0,16)+'...', timestamp: v.createdAt
      })),
      recentUsers: recentUsers.map(u => ({
        name: u.name, state: u.state, hasVoted: u.hasVoted, createdAt: u.createdAt
      })),
      blockchain: { blocks: blockCount, nodes: 12, synced: true },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Dashboard error' });
  }
});

app.get('/admin/fraud', adminAuth, async (req, res) => {
  const flags = await FraudFlag.find().sort({ timestamp: -1 }).limit(50);
  res.json({ success: true, flags });
});

app.get('/admin/audit', adminAuth, async (req, res) => {
  const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(100);
  res.json({ success: true, logs });
});

app.patch('/admin/fraud/:id/resolve', adminAuth, async (req, res) => {
  await FraudFlag.findByIdAndUpdate(req.params.id, { resolved: true });
  res.json({ success: true, message: 'Fraud flag resolved' });
});

// ── GET /admin/export — CSV export ────────────────────────────────
app.get('/admin/export', adminAuth, async (req, res) => {
  const votes = await Vote.find().lean();
  const csv = [
    'level,party,state,lga,ward,hash_preview,block,timestamp',
    ...votes.map(v => `${v.level},${v.party},${v.state},${v.lga},${v.ward},${v.hash.slice(0,12)}...,${v.blockIndex},${v.createdAt}`)
  ].join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=wazobia_results_export.csv');
  res.send(csv);
});

// ================================================================
// HEALTH CHECK
// ================================================================
app.get('/health', (req, res) => {
  res.json({
    status:    'operational',
    timestamp: new Date().toISOString(),
    version:   '3.0.0',
    platform:  'Wazobia Elect AI',
    db:        mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    blockchain: { blocks: blockCount, nodes: 12 },
  });
});

// Serve frontend for any unmatched route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'), (err) => {
    if (err) res.json({ message: 'Wazobia Elect AI API — Place frontend in /public/index.html' });
  });
});

// ================================================================
// SOCKET.IO — REAL-TIME
// ================================================================
const connectedClients = new Map();

io.on('connection', (socket) => {
  console.log(`📡 Client connected: ${socket.id}`);
  connectedClients.set(socket.id, { connectedAt: new Date() });
  io.emit('clientCount', connectedClients.size);

  // Send current state to new connection
  getLiveResults().then(data => socket.emit('liveResults', data)).catch(() => {});

  socket.on('subscribeState', (state) => {
    socket.join(`state:${state}`);
  });

  socket.on('disconnect', () => {
    connectedClients.delete(socket.id);
    io.emit('clientCount', connectedClients.size);
    console.log(`📴 Client disconnected: ${socket.id}`);
  });
});

// ================================================================
// DEMO DATA SEEDER
// ================================================================
async function seedDemoData() {
  try {
    const count = await User.countDocuments();
    if (count > 0) return;

    console.log('🌱 Seeding demo voter data...');
    const demoVoters = [
      { name:'Adaeze Okonkwo',  email:'adaeze@demo.ng',   nin:'12345678901', state:'Anambra',  lga:'Awka South',     ward:'Ward 07', pollingUnit:'Unit 003 — Awka Town Hall' },
      { name:'Emeka Nwosu',     email:'emeka@demo.ng',    nin:'98765432109', state:'Anambra',  lga:'Onitsha North',  ward:'Ward 02', pollingUnit:'Unit 015 — Onitsha Central' },
      { name:'Babatunde Adeyemi',email:'tunde@demo.ng',   nin:'55443322110', state:'Lagos',    lga:'Ikeja',          ward:'Ward 05', pollingUnit:'Unit 009 — Ikeja Council Hall' },
      { name:'Fatima Musa',     email:'fatima@demo.ng',   nin:'11223344556', state:'Kano',     lga:'Kano Municipal', ward:'Ward 12', pollingUnit:'Unit 042 — Kano GRA' },
      { name:'Chukwuemeka Eze', email:'chukwu@demo.ng',   nin:'22334455667', state:'Imo',      lga:'Owerri North',   ward:'Ward 03', pollingUnit:'Unit 007 — Owerri Town' },
      { name:'Amina Suleiman',  email:'amina@demo.ng',    nin:'33445566778', state:'Kaduna',   lga:'Kaduna North',   ward:'Ward 09', pollingUnit:'Unit 021 — Kaduna Central' },
    ];

    for (const v of demoVoters) {
      const hashed = await bcrypt.hash('Demo1234!', 12);
      await new User({ ...v, password: hashed, isVerified: true }).save();
    }

    // Create admin
    const adminPwd = await bcrypt.hash('WazobiaAdmin2027!', 12);
    await new User({ name:'INEC Administrator', email:'admin@inec.gov.ng', nin:'00000000001', password: adminPwd, role:'admin', isVerified: true }).save();

    console.log(`✅ Demo data seeded: ${demoVoters.length + 1} users created`);
    console.log('   Demo NINs: 12345678901, 98765432109, 55443322110, 11223344556');
    console.log('   Demo password: Demo1234!');
    console.log('   Admin email: admin@inec.gov.ng | Admin key header: x-admin-key: INEC_ADMIN_2027');

  } catch (err) {
    console.warn('Seed skipped:', err.message);
  }
}

// ================================================================
// START SERVER
// ================================================================
server.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════╗
║          WAZOBIA ELECT AI — BACKEND v3.0                 ║
║          Nigeria 2027 Digital Electoral Platform         ║
╠══════════════════════════════════════════════════════════╣
║  🚀 Server:       http://localhost:${PORT}                  ║
║  📊 Dashboard:    http://localhost:${PORT}/admin/dashboard  ║
║  ✅ Health:       http://localhost:${PORT}/health           ║
║  ⛓️  Blockchain:  http://localhost:${PORT}/blockchain        ║
║  🗳  Vote API:    POST http://localhost:${PORT}/vote         ║
╠══════════════════════════════════════════════════════════╣
║  Admin key: INEC_ADMIN_2027 (x-admin-key header)         ║
║  MongoDB:   ${MONGO_URI.padEnd(36)} ║
╚══════════════════════════════════════════════════════════╝
  `);
});
